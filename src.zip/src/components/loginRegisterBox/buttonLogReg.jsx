function ButtonLogReg(props){
  let {TextoBtn} = props;
  return(
    <button className="Button__LogReg">
      {TextoBtn}
    </button>
  )
}

export { ButtonLogReg }