import CarRegister from "../../components/carRegister/carRegister"
import UserContact from "../../components/carRegister/userContact"

const PublshCar = () =>{
  return(
    <main>
      <UserContact/>
      <CarRegister/>
    </main>
  )
}

export default PublshCar;