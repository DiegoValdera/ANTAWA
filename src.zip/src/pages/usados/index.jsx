const Usados = () => {
    return ( 
        <main>
            <h3>Pagina de usados</h3> 
        </main>
    );
}
 
export default Usados;

