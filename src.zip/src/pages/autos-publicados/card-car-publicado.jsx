
const CardCarPublish = () => {
  return(
    <p>Hola</p>
  )
}

export default CardCarPublish